package com.avynel

import com.google.gson.Gson

data class AIProvider(
    val id: String = System.currentTimeMillis().toString(),
    var name: String,
    var apiKey: String = "",
    var endpoint: String = "",
    var model: String = "",
    var isActive: Boolean = false,
    var providerType: ProviderType = ProviderType.CUSTOM,
    var isOnline: Boolean = true
) {
    enum class ProviderType {
        OPENAI,
        DEEPSEEK,
        GROQ,
        GEMINI,
        CUSTOM
    }
    
    companion object {
        fun getDefaultProviders(): List<AIProvider> {
            return listOf(
                AIProvider(
                    name = "OpenAI",
                    endpoint = "https://api.openai.com/v1/chat/completions",
                    model = "gpt-3.5-turbo",
                    providerType = ProviderType.OPENAI
                ),
                AIProvider(
                    name = "DeepSeek",
                    endpoint = "https://api.deepseek.com/chat/completions",
                    model = "deepseek-chat",
                    providerType = ProviderType.DEEPSEEK
                ),
                AIProvider(
                    name = "Groq",
                    endpoint = "https://api.groq.com/openai/v1/chat/completions",
                    model = "mixtral-8x7b-32768",
                    providerType = ProviderType.GROQ
                ),
                AIProvider(
                    name = "Gemini",
                    endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent",
                    model = "gemini-pro",
                    providerType = ProviderType.GEMINI
                )
            )
        }
    }
    
    fun toJson(): String {
        return Gson().toJson(this)
    }
    
    companion object {
        fun fromJson(json: String): AIProvider {
            return Gson().fromJson(json, AIProvider::class.java)
        }
    }
}