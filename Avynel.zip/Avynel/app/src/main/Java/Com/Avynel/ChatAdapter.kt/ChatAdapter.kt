package com.avynel

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Locale

class ChatAdapter(private var messages: MutableList<Message> = mutableListOf()) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    
    companion object {
        private const val VIEW_TYPE_USER = 1
        private const val VIEW_TYPE_AI = 2
        private const val VIEW_TYPE_THINKING = 3
        private const val VIEW_TYPE_ERROR = 4
    }
    
    private val dateFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        
        return when (viewType) {
            VIEW_TYPE_USER -> {
                val view = inflater.inflate(R.layout.item_user_message, parent, false)
                UserMessageViewHolder(view)
            }
            VIEW_TYPE_THINKING -> {
                val view = inflater.inflate(R.layout.item_ai_message, parent, false)
                ThinkingMessageViewHolder(view)
            }
            VIEW_TYPE_ERROR -> {
                val view = inflater.inflate(R.layout.item_ai_message, parent, false)
                ErrorMessageViewHolder(view)
            }
            else -> {
                val view = inflater.inflate(R.layout.item_ai_message, parent, false)
                AIMessageViewHolder(view)
            }
        }
    }
    
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val message = messages[position]
        
        when (holder) {
            is UserMessageViewHolder -> holder.bind(message)
            is AIMessageViewHolder -> holder.bind(message)
            is ThinkingMessageViewHolder -> holder.bind(message)
            is ErrorMessageViewHolder -> holder.bind(message)
        }
    }
    
    override fun getItemCount(): Int = messages.size
    
    override fun getItemViewType(position: Int): Int {
        val message = messages[position]
        
        return when {
            message.isFromUser -> VIEW_TYPE_USER
            message.isThinking -> VIEW_TYPE_THINKING
            message.isError -> VIEW_TYPE_ERROR
            else -> VIEW_TYPE_AI
        }
    }
    
    fun addMessage(message: Message) {
        messages.add(message)
        notifyItemInserted(messages.size - 1)
    }
    
    fun updateLastMessage(content: String, isError: Boolean = false) {
        if (messages.isNotEmpty()) {
            val lastIndex = messages.size - 1
            val lastMessage = messages[lastIndex]
            
            if (lastMessage.isThinking) {
                messages[lastIndex] = if (isError) {
                    Message.createErrorMessage(content)
                } else {
                    Message.createAIMessage(content)
                }
                notifyItemChanged(lastIndex)
            }
        }
    }
    
    fun clear() {
        messages.clear()
        notifyDataSetChanged()
    }
    
    inner class UserMessageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val messageText: TextView = itemView.findViewById(R.id.message_text)
        private val timeText: TextView = itemView.findViewById(R.id.time_text)
        
        fun bind(message: Message) {
            messageText.text = message.content
            timeText.text = dateFormat.format(message.timestamp)
        }
    }
    
    inner class AIMessageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val messageText: TextView = itemView.findViewById(R.id.message_text)
        private val timeText: TextView = itemView.findViewById(R.id.time_text)
        
        fun bind(message: Message) {
            messageText.text = message.content
            timeText.text = dateFormat.format(message.timestamp)
        }
    }
    
    inner class ThinkingMessageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val messageText: TextView = itemView.findViewById(R.id.message_text)
        
        fun bind(message: Message) {
            messageText.text = message.content
            // You could add a loading animation here
        }
    }
    
    inner class ErrorMessageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val messageText: TextView = itemView.findViewById(R.id.message_text)
        
        fun bind(message: Message) {
            messageText.text = message.content
            messageText.setTextColor(itemView.context.getColor(android.R.color.holo_red_dark))
        }
    }
}