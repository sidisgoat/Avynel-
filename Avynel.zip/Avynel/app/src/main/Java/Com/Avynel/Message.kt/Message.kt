package com.avynel

import java.util.Date

data class Message(
    val id: String = System.currentTimeMillis().toString() + (0..999).random(),
    val content: String,
    val isFromUser: Boolean,
    val timestamp: Date = Date(),
    var isThinking: Boolean = false,
    var isError: Boolean = false
) {
    companion object {
        fun createUserMessage(content: String): Message {
            return Message(content = content, isFromUser = true)
        }
        
        fun createAIMessage(content: String): Message {
            return Message(content = content, isFromUser = false)
        }
        
        fun createThinkingMessage(): Message {
            return Message(content = "AI is thinking...", isFromUser = false, isThinking = true)
        }
        
        fun createErrorMessage(content: String): Message {
            return Message(content = content, isFromUser = false, isError = true)
        }
    }
}