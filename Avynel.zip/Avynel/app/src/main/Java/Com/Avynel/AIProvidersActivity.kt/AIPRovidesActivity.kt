package com.avynel

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class AIProvidersActivity : AppCompatActivity() {
    
    private lateinit var providersRecyclerView: RecyclerView
    private lateinit var adapter: ProvidersAdapter
    private lateinit var providerManager: AIProviderManager
    private lateinit var addProviderButton: Button
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ai_providers)
        
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "AI Providers"
        
        providerManager = AIProviderManager(this)
        initViews()
        setupRecyclerView()
    }
    
    private fun initViews() {
        providersRecyclerView = findViewById(R.id.providers_recycler_view)
        addProviderButton = findViewById(R.id.add_provider_button)
        
        addProviderButton.setOnClickListener {
            showAddProviderDialog()
        }
    }
    
    private fun setupRecyclerView() {
        adapter = ProvidersAdapter(providerManager.getProviders()) { provider ->
            showEditProviderDialog(provider)
        }
        providersRecyclerView.layoutManager = LinearLayoutManager(this)
        providersRecyclerView.adapter = adapter
    }
    
    private fun showAddProviderDialog() {
        showProviderDialog(null)
    }
    
    private fun showEditProviderDialog(provider: AIProvider) {
        showProviderDialog(provider)
    }
    
    private fun showProviderDialog(existingProvider: AIProvider?) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_provider, null)
        
        val nameInput = dialogView.findViewById<EditText>(R.id.provider_name_input)
        val apiKeyInput = dialogView.findViewById<EditText>(R.id.api_key_input)
        val endpointInput = dialogView.findViewById<EditText>(R.id.endpoint_input)
        val modelInput = dialogView.findViewById<EditText>(R.id.model_input)
        val typeSpinner = dialogView.findViewById<Spinner>(R.id.provider_type_spinner)
        
        // Setup spinner
        val types = arrayOf("Custom", "OpenAI", "DeepSeek", "Groq", "Gemini")
        val typeAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, types)
        typeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        typeSpinner.adapter = typeAdapter
        
        // Pre-fill if editing
        existingProvider?.let { provider ->
            nameInput.setText(provider.name)
            apiKeyInput.setText(provider.apiKey)
            endpointInput.setText(provider.endpoint)
            modelInput.setText(provider.model)
            typeSpinner.setSelection(when (provider.providerType) {
                AIProvider.ProviderType.CUSTOM -> 0
                AIProvider.ProviderType.OPENAI -> 1
                AIProvider.ProviderType.DEEPSEEK -> 2
                AIProvider.ProviderType.GROQ -> 3
                AIProvider.ProviderType.GEMINI -> 4
            })
        }
        
        AlertDialog.Builder(this)
            .setTitle(if (existingProvider == null) "Add Provider" else "Edit Provider")
            .setView(dialogView)
            .setPositiveButton("Save") { _, _ ->
                val provider = existingProvider?.copy() ?: AIProvider(
                    name = nameInput.text.toString(),
                    apiKey = apiKeyInput.text.toString(),
                    endpoint = endpointInput.text.toString(),
                    model = modelInput.text.toString(),
                    providerType = when (typeSpinner.selectedItemPosition) {
                        1 -> AIProvider.ProviderType.OPENAI
                        2 -> AIProvider.ProviderType.DEEPSEEK
                        3 -> AIProvider.ProviderType.GROQ
                        4 -> AIProvider.ProviderType.GEMINI
                        else -> AIProvider.ProviderType.CUSTOM
                    }
                )
                
                providerManager.saveProvider(provider)
                adapter.updateProviders(providerManager.getProviders())
            }
            .setNegativeButton("Cancel", null)
            .setNeutralButton("Delete") { _, _ ->
                existingProvider?.let {
                    AlertDialog.Builder(this)
                        .setTitle("Delete Provider")
                        .setMessage("Are you sure you want to delete ${it.name}?")
                        .setPositiveButton("Delete") { _, _ ->
                            providerManager.deleteProvider(it.id)
                            adapter.updateProviders(providerManager.getProviders())
                        }
                        .setNegativeButton("Cancel", null)
                        .show()
                }
            }
            .show()
    }
    
    inner class ProvidersAdapter(
        private var providers: List<AIProvider>,
        private val onItemClick: (AIProvider) -> Unit
    ) : RecyclerView.Adapter<ProvidersAdapter.ViewHolder>() {
        
        inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            private val nameText: TextView = itemView.findViewById(R.id.provider_name)
            private val statusText: TextView = itemView.findViewById(R.id.provider_status)
            private val typeText: TextView = itemView.findViewById(R.id.provider_type)
            private val activeSwitch: Switch = itemView.findViewById(R.id.active_switch)
            
            fun bind(provider: AIProvider) {
                nameText.text = provider.name
                typeText.text = when (provider.providerType) {
                    AIProvider.ProviderType.CUSTOM -> "Custom"
                    AIProvider.ProviderType.OPENAI -> "OpenAI"
                    AIProvider.ProviderType.DEEPSEEK -> "DeepSeek"
                    AIProvider.ProviderType.GROQ -> "Groq"
                    AIProvider.ProviderType.GEMINI -> "Gemini"
                }
                
                if (provider.isOnline) {
                    statusText.text = if (provider.apiKey.isNotEmpty()) "Configured" else "Not Configured"
                    statusText.setTextColor(itemView.context.getColor(
                        if (provider.apiKey.isNotEmpty()) android.R.color.holo_green_dark 
                        else android.R.color.holo_red_dark
                    ))
                } else {
                    statusText.text = "Offline"
                    statusText.setTextColor(itemView.context.getColor(android.R.color.darker_gray))
                }
                
                activeSwitch.isChecked = provider.isActive
                activeSwitch.setOnCheckedChangeListener { _, isChecked ->
                    if (isChecked) {
                        providerManager.setActiveProvider(provider.id)
                        updateProviders(providerManager.getProviders())
                    }
                }
                
                itemView.setOnClickListener {
                    onItemClick(provider)
                }
            }
        }
        
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_provider, parent, false)
            return ViewHolder(view)
        }
        
        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            holder.bind(providers[position])
        }
        
        override fun getItemCount(): Int = providers.size
        
        fun updateProviders(newProviders: List<AIProvider>) {
            providers = newProviders
            notifyDataSetChanged()
        }
    }
    
    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}