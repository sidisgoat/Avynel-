package com.avynel

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class AIProviderManager(context: Context) {
    private val sharedPreferences: SharedPreferences =
        context.getSharedPreferences("ai_providers", Context.MODE_PRIVATE)
    private val gson = Gson()
    
    private val OFFLINE_PROVIDER = AIProvider(
        id = "offline",
        name = "Offline AI",
        isActive = false,
        isOnline = false
    )
    
    fun saveProvider(provider: AIProvider) {
        val providers = getProviders().toMutableList()
        val existingIndex = providers.indexOfFirst { it.id == provider.id }
        
        if (existingIndex != -1) {
            providers[existingIndex] = provider
        } else {
            providers.add(provider)
        }
        
        saveProviders(providers)
    }
    
    fun deleteProvider(providerId: String) {
        val providers = getProviders().toMutableList()
        providers.removeAll { it.id == providerId }
        saveProviders(providers)
    }
    
    fun getProviders(): List<AIProvider> {
        val json = sharedPreferences.getString("providers_list", null)
        return if (json != null) {
            val type = object : TypeToken<List<AIProvider>>() {}.type
            gson.fromJson(json, type) ?: getDefaultProviders()
        } else {
            getDefaultProviders()
        }
    }
    
    private fun getDefaultProviders(): List<AIProvider> {
        return AIProvider.getDefaultProviders() + OFFLINE_PROVIDER
    }
    
    private fun saveProviders(providers: List<AIProvider>) {
        val json = gson.toJson(providers)
        sharedPreferences.edit().putString("providers_list", json).apply()
    }
    
    fun getActiveProvider(): AIProvider {
        val providers = getProviders()
        return providers.find { it.isActive } ?: OFFLINE_PROVIDER
    }
    
    fun setActiveProvider(providerId: String) {
        val providers = getProviders().map { provider ->
            provider.copy(isActive = provider.id == providerId)
        }
        saveProviders(providers)
    }
    
    fun getOfflineProvider(): AIProvider {
        return OFFLINE_PROVIDER
    }
    
    fun isOfflineMode(): Boolean {
        return getActiveProvider().id == "offline"
    }
}