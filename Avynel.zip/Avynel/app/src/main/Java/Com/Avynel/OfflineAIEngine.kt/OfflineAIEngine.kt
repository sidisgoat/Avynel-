package com.avynel

import kotlin.random.Random

class OfflineAIEngine {
    private val responses = listOf(
        "I'm running in offline mode. You can connect me to online services for more intelligent responses!",
        "This is a placeholder response from offline AI. Try switching to online mode for real AI responses.",
        "Offline AI here! I'm limited but functional. Configure online providers in settings for better conversations.",
        "I'm currently in offline mode. Would you like to switch to online AI in the settings?",
        "As an offline AI, I can't access the internet. My responses are pre-programmed for demonstration.",
        "You're using the offline version. To get smarter responses, please configure an online AI provider.",
        "Offline response: I'm simulating AI behavior. Real AI requires internet connection and API keys.",
        "This response is generated locally. For actual AI conversations, set up OpenAI, DeepSeek, or other providers."
    )
    
    private val greetings = listOf(
        "Hello! I'm Avynel AI running offline.",
        "Hi there! I'm your offline AI assistant.",
        "Greetings! I'm available offline.",
        "Welcome to Avynel AI (Offline Mode)."
    )
    
    private val questions = mapOf(
        "how are you" to "I'm functioning well in offline mode!",
        "what can you do" to "I can chat offline, but for advanced features, try online mode.",
        "who are you" to "I'm Avynel AI, your hybrid chatbot assistant.",
        "help" to "You can: 1) Type messages 2) Switch themes 3) Configure AI providers in settings",
        "offline" to "Yes, I'm running offline. Check settings to configure online providers."
    )
    
    fun generateOfflineResponse(input: String): String {
        val lowerInput = input.lowercase()
        
        // Check for greetings
        if (lowerInput.contains("hello") || lowerInput.contains("hi") || lowerInput.contains("hey")) {
            return greetings.random()
        }
        
        // Check for specific questions
        for ((key, response) in questions) {
            if (lowerInput.contains(key)) {
                return response
            }
        }
        
        // Check for theme-related queries
        if (lowerInput.contains("theme") || lowerInput.contains("color")) {
            return "You can change themes from the menu! Try Light, Dark Tech, Basic Android, or Love theme."
        }
        
        if (lowerInput.contains("settings") || lowerInput.contains("configure")) {
            return "Go to Settings > AI Providers to add OpenAI, DeepSeek, Groq, Gemini, or custom APIs."
        }
        
        if (lowerInput.contains("online")) {
            return "To use online AI, add an API provider in settings and make sure you have internet connection."
        }
        
        // Default random response
        return responses.random()
    }
    
    fun getWelcomeMessage(): String {
        return "Welcome to Avynel! I'm your hybrid AI assistant. I can work both online and offline. " +
               "Configure your AI providers in settings to get started with online mode, or continue chatting with me offline."
    }
}