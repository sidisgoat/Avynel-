package com.avynel

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration

class ThemeManager(context: Context) {
    companion object {
        const val THEME_LIGHT = "light"
        const val THEME_DARK_TECH = "dark_tech"
        const val THEME_BASIC = "basic"
        const val THEME_LOVE = "love"
        
        private const val PREF_THEME = "app_theme"
    }
    
    private val sharedPreferences: SharedPreferences =
        context.getSharedPreferences("theme_prefs", Context.MODE_PRIVATE)
    
    fun getCurrentTheme(): String {
        return sharedPreferences.getString(PREF_THEME, THEME_LIGHT) ?: THEME_LIGHT
    }
    
    fun setTheme(theme: String) {
        sharedPreferences.edit().putString(PREF_THEME, theme).apply()
    }
    
    fun applyTheme(activity: Activity) {
        when (getCurrentTheme()) {
            THEME_DARK_TECH -> activity.setTheme(R.style.Theme_Avynel_DarkTech)
            THEME_BASIC -> activity.setTheme(R.style.Theme_Avynel_Basic)
            THEME_LOVE -> activity.setTheme(R.style.Theme_Avynel_Love)
            else -> activity.setTheme(R.style.Theme_Avynel)
        }
    }
    
    fun isDarkTheme(): Boolean {
        return getCurrentTheme() == THEME_DARK_TECH
    }
    
    fun getThemeName(theme: String): String {
        return when (theme) {
            THEME_LIGHT -> "Light"
            THEME_DARK_TECH -> "Dark Tech"
            THEME_BASIC -> "Basic Android"
            THEME_LOVE -> "Love Theme"
            else -> "Light"
        }
    }
    
    fun getAllThemes(): List<String> {
        return listOf(THEME_LIGHT, THEME_DARK_TECH, THEME_BASIC, THEME_LOVE)
    }
}