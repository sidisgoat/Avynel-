package com.avynel

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class OnlineAIClient(context: Context) {
    private val providerManager = AIProviderManager(context)
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()
    
    suspend fun sendMessage(message: String): Result<String> = withContext(Dispatchers.IO) {
        val provider = providerManager.getActiveProvider()
        
        return@withContext try {
            when (provider.providerType) {
                AIProvider.ProviderType.OPENAI -> callOpenAI(provider, message)
                AIProvider.ProviderType.DEEPSEEK -> callDeepSeek(provider, message)
                AIProvider.ProviderType.GROQ -> callGroq(provider, message)
                AIProvider.ProviderType.GEMINI -> callGemini(provider, message)
                else -> callCustomAPI(provider, message)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    private fun callOpenAI(provider: AIProvider, message: String): Result<String> {
        val json = JSONObject().apply {
            put("model", provider.model)
            put("messages", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", message)
                })
            })
            put("max_tokens", 1000)
            put("temperature", 0.7)
        }
        
        val request = Request.Builder()
            .url(provider.endpoint)
            .header("Authorization", "Bearer ${provider.apiKey}")
            .header("Content-Type", "application/json")
            .post(json.toString().toRequestBody("application/json".toMediaType()))
            .build()
        
        return executeRequest(request)
    }
    
    private fun callDeepSeek(provider: AIProvider, message: String): Result<String> {
        val json = JSONObject().apply {
            put("model", provider.model)
            put("messages", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", message)
                })
            })
            put("max_tokens", 2000)
            put("temperature", 0.7)
        }
        
        val request = Request.Builder()
            .url(provider.endpoint)
            .header("Authorization", "Bearer ${provider.apiKey}")
            .header("Content-Type", "application/json")
            .post(json.toString().toRequestBody("application/json".toMediaType()))
            .build()
        
        return executeRequest(request)
    }
    
    private fun callGroq(provider: AIProvider, message: String): Result<String> {
        val json = JSONObject().apply {
            put("model", provider.model)
            put("messages", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", message)
                })
            })
            put("temperature", 0.7)
        }
        
        val request = Request.Builder()
            .url(provider.endpoint)
            .header("Authorization", "Bearer ${provider.apiKey}")
            .header("Content-Type", "application/json")
            .post(json.toString().toRequestBody("application/json".toMediaType()))
            .build()
        
        return executeRequest(request)
    }
    
    private fun callGemini(provider: AIProvider, message: String): Result<String> {
        val json = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", message)
                        })
                    })
                })
            })
        }
        
        val url = "${provider.endpoint}?key=${provider.apiKey}"
        val request = Request.Builder()
            .url(url)
            .header("Content-Type", "application/json")
            .post(json.toString().toRequestBody("application/json".toMediaType()))
            .build()
        
        return executeRequest(request)
    }
    
    private fun callCustomAPI(provider: AIProvider, message: String): Result<String> {
        val json = JSONObject().apply {
            put("prompt", message)
            put("model", provider.model)
        }
        
        val request = Request.Builder()
            .url(provider.endpoint)
            .header("Authorization", "Bearer ${provider.apiKey}")
            .header("Content-Type", "application/json")
            .post(json.toString().toRequestBody("application/json".toMediaType()))
            .build()
        
        return executeRequest(request)
    }
    
    private fun executeRequest(request: Request): Result<String> {
        return try {
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val responseBody = response.body?.string()
                    if (responseBody != null) {
                        Result.success(parseResponse(responseBody))
                    } else {
                        Result.failure(IOException("Empty response body"))
                    }
                } else {
                    Result.failure(IOException("HTTP ${response.code}: ${response.message}"))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    private fun parseResponse(responseBody: String): String {
        return try {
            val json = JSONObject(responseBody)
            
            when {
                json.has("choices") -> {
                    val choices = json.getJSONArray("choices")
                    if (choices.length() > 0) {
                        val choice = choices.getJSONObject(0)
                        if (choice.has("message")) {
                            choice.getJSONObject("message").getString("content")
                        } else if (choice.has("text")) {
                            choice.getString("text")
                        } else {
                            choice.toString()
                        }
                    } else {
                        "No response from AI"
                    }
                }
                json.has("candidates") -> {
                    val candidates = json.getJSONArray("candidates")
                    if (candidates.length() > 0) {
                        val candidate = candidates.getJSONObject(0)
                        if (candidate.has("content")) {
                            val content = candidate.getJSONObject("content")
                            val parts = content.getJSONArray("parts")
                            if (parts.length() > 0) {
                                parts.getJSONObject(0).getString("text")
                            } else {
                                "No text in response"
                            }
                        } else {
                            candidate.toString()
                        }
                    } else {
                        "No candidates in response"
                    }
                }
                json.has("text") -> json.getString("text")
                else -> responseBody
            }
        } catch (e: Exception) {
            "Error parsing response: ${e.message}"
        }
    }
}