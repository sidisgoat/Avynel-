package com.avynel

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {
    
    private lateinit var chatRecyclerView: RecyclerView
    private lateinit var messageInput: EditText
    private lateinit var sendButton: ImageButton
    private lateinit var adapter: ChatAdapter
    private lateinit var providerManager: AIProviderManager
    private lateinit var onlineAIClient: OnlineAIClient
    private lateinit var offlineAIEngine: OfflineAIEngine
    private lateinit var themeManager: ThemeManager
    private lateinit var currentModeText: TextView
    
    override fun onCreate(savedInstanceState: Bundle?) {
        themeManager = ThemeManager(this)
        themeManager.applyTheme(this)
        
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        initViews()
        setupRecyclerView()
        setupManagers()
        showWelcomeMessage()
    }
    
    private fun initViews() {
        chatRecyclerView = findViewById(R.id.chat_recycler_view)
        messageInput = findViewById(R.id.message_input)
        sendButton = findViewById(R.id.send_button)
        currentModeText = findViewById(R.id.current_mode_text)
        
        sendButton.setOnClickListener {
            sendMessage()
        }
        
        // Send on Enter key
        messageInput.setOnEditorActionListener { _, _, _ ->
            sendMessage()
            true
        }
    }
    
    private fun setupRecyclerView() {
        adapter = ChatAdapter()
        chatRecyclerView.layoutManager = LinearLayoutManager(this).apply {
            stackFromEnd = true
        }
        chatRecyclerView.adapter = adapter
    }
    
    private fun setupManagers() {
        providerManager = AIProviderManager(this)
        onlineAIClient = OnlineAIClient(this)
        offlineAIEngine = OfflineAIEngine()
        updateModeDisplay()
    }
    
    private fun showWelcomeMessage() {
        val welcomeMessage = offlineAIEngine.getWelcomeMessage()
        adapter.addMessage(Message.createAIMessage(welcomeMessage))
    }
    
    private fun sendMessage() {
        val message = messageInput.text.toString().trim()
        if (message.isEmpty()) return
        
        // Add user message
        adapter.addMessage(Message.createUserMessage(message))
        messageInput.text.clear()
        
        // Scroll to bottom
        chatRecyclerView.smoothScrollToPosition(adapter.itemCount - 1)
        
        // Show thinking indicator
        adapter.addMessage(Message.createThinkingMessage())
        chatRecyclerView.smoothScrollToPosition(adapter.itemCount - 1)
        
        // Process message
        CoroutineScope(Dispatchers.Main).launch {
            try {
                val response = if (providerManager.isOfflineMode()) {
                    // Offline mode
                    withContext(Dispatchers.IO) {
                        offlineAIEngine.generateOfflineResponse(message)
                    }
                } else {
                    // Online mode
                    onlineAIClient.sendMessage(message).getOrElse {
                        "Error: ${it.message}"
                    }
                }
                
                adapter.updateLastMessage(response)
            } catch (e: Exception) {
                adapter.updateLastMessage("Error: ${e.message}", true)
            }
            
            chatRecyclerView.smoothScrollToPosition(adapter.itemCount - 1)
        }
    }
    
    private fun updateModeDisplay() {
        val provider = providerManager.getActiveProvider()
        currentModeText.text = if (providerManager.isOfflineMode()) {
            "Offline Mode"
        } else {
            "Online: ${provider.name}"
        }
    }
    
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }
    
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_settings -> {
                startActivity(Intent(this, AIProvidersActivity::class.java))
                true
            }
            R.id.menu_theme -> {
                showThemeSelector()
                true
            }
            R.id.menu_clear -> {
                clearChat()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
    
    private fun showThemeSelector() {
        val themes = themeManager.getAllThemes()
        val themeNames = themes.map { themeManager.getThemeName(it) }.toTypedArray()
        
        AlertDialog.Builder(this)
            .setTitle("Select Theme")
            .setItems(themeNames) { _, which ->
                themeManager.setTheme(themes[which])
                recreate() // Restart activity to apply theme
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    private fun clearChat() {
        AlertDialog.Builder(this)
            .setTitle("Clear Chat")
            .setMessage("Are you sure you want to clear all messages?")
            .setPositiveButton("Clear") { _, _ ->
                adapter.clear()
                showWelcomeMessage()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    override fun onResume() {
        super.onResume()
        updateModeDisplay()
    }
}