#!/bin/bash
echo "Building Avynel APK..."

# Create necessary directories
mkdir -p build/classes
mkdir -p build/apk

# Compile Java/Kotlin files
find . -name "*.kt" -exec ecj -cp /data/data/com.termux/files/usr/share/java/android.jar -d build/classes {} \;

# Convert to dex
dx --dex --output=build/classes.dex build/classes/

# Package APK
aapt package -f -M AndroidManifest.xml -S res -I /data/data/com.termux/files/usr/share/java/android.jar -F build/avynel.apk
aapt add build/avynel.apk build/classes.dex

# Sign APK
apksigner sign --ks debug.keystore --ks-pass pass:android build/avynel.apk

echo "APK built: build/avynel.apk"
